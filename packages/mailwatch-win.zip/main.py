"""
MailWatch 后端服务
双击「启动 MailWatch.bat」即可，无需其他操作
"""

import imaplib
import email
import json
import os
import threading
import time
import webbrowser
from datetime import datetime, date
from email.header import decode_header
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import List, Optional

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from openai import OpenAI
from pydantic import BaseModel
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
ENV_PATH = ROOT / ".env"
os.chdir(ROOT)
load_dotenv(ENV_PATH)

app = FastAPI(title="MailWatch API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

if (ROOT / "static").exists():
    app.mount("/static", StaticFiles(directory=str(ROOT / "static")), name="static")


@app.get("/")
def serve_frontend():
    index = ROOT / "static" / "index.html"
    if index.exists():
        return FileResponse(str(index))
    return {"message": "MailWatch API 运行中", "docs": "/docs"}


class AccountConfig(BaseModel):
    type: str
    email: str
    password: str
    name: str = ""


class AnalyzeRequest(BaseModel):
    accounts: List[AccountConfig]
    focus: str = "亚马逊运营相关邮件"
    system_prompt: Optional[str] = None
    max_emails: int = 50


class ConfigRequest(BaseModel):
    api_key: str
    model: str = "gpt-4o-mini"


def is_api_configured() -> bool:
    key = os.getenv("OPENAI_API_KEY", "").strip()
    return bool(key) and key not in ("sk-your-key-here", "sk-...")


def write_env(api_key: str, model: str = "gpt-4o-mini"):
    lines = []
    if ENV_PATH.exists():
        lines = ENV_PATH.read_text(encoding="utf-8").splitlines()

    updated = {"OPENAI_API_KEY": api_key, "OPENAI_MODEL": model}
    new_lines = []
    seen = set()
    for line in lines:
        key = line.split("=", 1)[0].strip() if "=" in line else ""
        if key in updated:
            new_lines.append(f"{key}={updated[key]}")
            seen.add(key)
        else:
            new_lines.append(line)
    for key, val in updated.items():
        if key not in seen:
            new_lines.append(f"{key}={val}")

    ENV_PATH.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    os.environ["OPENAI_API_KEY"] = api_key
    os.environ["OPENAI_MODEL"] = model
    load_dotenv(ENV_PATH, override=True)


@app.get("/config/status")
def config_status():
    return {
        "configured": is_api_configured(),
        "model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
    }


@app.post("/config")
def save_config(req: ConfigRequest):
    key = req.api_key.strip()
    if not key.startswith("sk-"):
        raise HTTPException(status_code=400, detail="API Key 格式不正确，应以 sk- 开头")
    write_env(key, req.model.strip() or "gpt-4o-mini")
    return {"ok": True}


IMAP_SERVERS = {
    "163": ("imap.163.com", 993),
    "126": ("imap.126.com", 993),
    "yeah": ("imap.yeah.net", 993),
    "gmail": ("imap.gmail.com", 993),
}

NETEASE_TYPES = {"163", "126", "yeah"}

if "ID" not in imaplib.Commands:
    imaplib.Commands["ID"] = ("AUTH",)


def send_netease_imap_id(mail) -> None:
    """网易邮箱要求 login 后、select 前声明客户端 ID。"""
    tag = mail._new_tag()
    mail.send(tag + b' ID ("name" "MailWatch" "version" "1.0" "vendor" "MailWatch")\r\n')
    typ, data = mail._get_tagged_response(tag)
    if typ != "OK":
        err = ""
        if data:
            err = data[0].decode(errors="replace") if isinstance(data[0], bytes) else str(data[0])
        raise Exception(f"IMAP ID 被拒绝: {err or typ}")


def select_inbox(mail) -> None:
    status, data = mail.select("INBOX")
    if status == "OK":
        return
    detail = ""
    if data:
        detail = data[0].decode(errors="replace") if isinstance(data[0], bytes) else str(data[0])
    raise Exception(detail or "无法选择收件箱")


def decode_str(s):
    if not s:
        return ""
    parts = decode_header(s)
    result = []
    for part, charset in parts:
        if isinstance(part, bytes):
            try:
                result.append(part.decode(charset or "utf-8", errors="replace"))
            except Exception:
                result.append(part.decode("gbk", errors="replace"))
        else:
            result.append(str(part))
    return "".join(result)


def get_email_body(msg) -> str:
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            cd = str(part.get("Content-Disposition", ""))
            if ct == "text/plain" and "attachment" not in cd:
                try:
                    charset = part.get_content_charset() or "utf-8"
                    body = part.get_payload(decode=True).decode(charset, errors="replace")
                    break
                except Exception:
                    pass
    else:
        try:
            charset = msg.get_content_charset() or "utf-8"
            body = msg.get_payload(decode=True).decode(charset, errors="replace")
        except Exception:
            pass
    return body[:500].strip()


CATEGORY_ORDER = ["风险邮件", "账号警告", "待处理", "重要邮件", "广告通知"]

DELIVERY_INCLUDE = (
    "已发货", "发货通知", "配送", "送达", "delivered", "shipped", "out for delivery",
    "tracking", "包裹", "运单", "快递", "物流更新", "delivery update", "on its way",
    "预计送达", "carrier", "in transit", "dispatch", "your order has",
)
DELIVERY_EXCLUDE = (
    "丢失", "损坏", "差异", "discrepancy", "lost", "damaged", "problem", "issue",
    "missing", "reimbursement", "调查", "claim", "投诉", "异常", "拒收", "退回",
    "fba货件问题", "inbound problem", "shortage", "overage",
)


def _email_text_blob(em: dict) -> str:
    return f"{em.get('subject', '')} {em.get('from', '')} {em.get('body', '')}".lower()


def is_routine_delivery(em: dict) -> bool:
    blob = _email_text_blob(em)
    if any(k.lower() in blob for k in DELIVERY_EXCLUDE):
        return False
    return any(k.lower() in blob for k in DELIVERY_INCLUDE)


def split_delivery_emails(emails: List[dict]):
    delivery, others = [], []
    for em in emails:
        (delivery if is_routine_delivery(em) else others).append(em)
    return others, delivery


def build_delivery_summaries(delivery: List[dict]) -> List[dict]:
    if not delivery:
        return []

    by_account: dict = {}
    for em in delivery:
        acct = em.get("account") or "默认邮箱"
        by_account.setdefault(acct, []).append(em)

    summaries = []
    for account, items in sorted(by_account.items()):
        shipped = delivered = 0
        for em in items:
            blob = _email_text_blob(em)
            if any(k in blob for k in ("送达", "delivered", "签收", "已收到")):
                delivered += 1
            elif any(k in blob for k in ("发货", "shipped", "dispatch", "on its way", "已发出")):
                shipped += 1

        in_transit = max(0, len(items) - shipped - delivered)
        parts = []
        if shipped:
            parts.append(f"发货 {shipped} 封")
        if delivered:
            parts.append(f"签收/送达 {delivered} 封")
        if in_transit:
            parts.append(f"在途更新 {in_transit} 封")
        if not parts:
            parts.append(f"物流通知 {len(items)} 封")

        summaries.append({
            "grouped": True,
            "groupType": "配送汇总",
            "account": account,
            "from": "配送物流",
            "time": items[0].get("time", "--:--"),
            "subject": f"配送通知汇总 · {len(items)} 封",
            "summary": f"该邮箱今日 {len(items)} 封配送类邮件：{'，'.join(parts)}。常规物流通知，无需逐封处理。",
            "category": "重要邮件",
            "tags": ["配送汇总"],
            "priority": "低",
            "groupCount": len(items),
        })
    return summaries


def enrich_report(result: dict, raw_total: Optional[int] = None) -> dict:
    stats = {cat: 0 for cat in CATEGORY_ORDER}
    emails = result.get("emails") or []
    for em in emails:
        cat = em.get("category") or "重要邮件"
        if cat not in stats:
            cat = "重要邮件"
            em["category"] = cat
        stats[cat] += 1
    result["categoryStats"] = stats
    result["urgent"] = stats["风险邮件"] + stats["账号警告"]
    result["needReply"] = stats["待处理"]
    result["handled"] = stats["广告通知"]
    order = {cat: i for i, cat in enumerate(CATEGORY_ORDER)}
    result["emails"] = sorted(
        emails,
        key=lambda e: (
            e.get("account") or "",
            1 if e.get("grouped") else 0,
            order.get(e.get("category"), 99),
        ),
    )
    if raw_total is not None:
        result["total"] = raw_total
    grouped = sum(e.get("groupCount", 1) for e in emails if e.get("grouped"))
    if grouped:
        result["deliveryGrouped"] = grouped
    return result


def fetch_today_emails(account: AccountConfig, max_emails: int = 50) -> List[dict]:
    server_host, server_port = IMAP_SERVERS.get(account.type, ("", 0))
    if not server_host:
        raise ValueError(f"不支持的邮箱类型: {account.type}")

    emails = []
    try:
        mail = imaplib.IMAP4_SSL(server_host, server_port)
        mail.login(account.email, account.password)

        if account.type in NETEASE_TYPES:
            send_netease_imap_id(mail)

        select_inbox(mail)

        today_str = date.today().strftime("%d-%b-%Y")
        status, data = mail.search(None, "SINCE", today_str)

        if status != "OK" or not data[0]:
            mail.logout()
            return []

        ids = data[0].split()[-max_emails:]

        for uid in reversed(ids):
            try:
                _, msg_data = mail.fetch(uid, "(RFC822)")
                if not msg_data or not msg_data[0]:
                    continue
                raw = msg_data[0][1]
                msg = email.message_from_bytes(raw)

                subject = decode_str(msg.get("Subject", "（无主题）"))
                from_addr = decode_str(msg.get("From", ""))
                body = get_email_body(msg)

                try:
                    dt = parsedate_to_datetime(msg.get("Date", ""))
                    time_str = dt.strftime("%H:%M")
                except Exception:
                    time_str = "--:--"

                emails.append({
                    "account": account.name or account.email,
                    "from": from_addr,
                    "time": time_str,
                    "subject": subject,
                    "body": body,
                })
            except Exception as e:
                print(f"解析邮件出错: {e}")
                continue

        mail.logout()
    except imaplib.IMAP4.error as e:
        msg = str(e)
        hint = ""
        if account.type in NETEASE_TYPES:
            hint = "。请确认：1) 已开启 IMAP  2) 使用的是授权码而非登录密码  3) 163 网页版设置里允许第三方客户端"
        raise HTTPException(
            status_code=400,
            detail=f"{account.email} 登录失败：{msg}{hint}",
        )
    except HTTPException:
        raise
    except Exception as e:
        msg = str(e)
        hint = ""
        if account.type in NETEASE_TYPES and ("Unsafe Login" in msg or "收件箱" in msg or "SELECT" in msg):
            hint = "。网易邮箱需使用 IMAP 授权码，并在网页版 设置→POP3/SMTP/IMAP 中开启 IMAP"
        raise HTTPException(status_code=500, detail=f"{account.email} 读取失败：{msg}{hint}")

    return emails


def analyze_with_gpt(emails: List[dict], focus: str, system_prompt: str = None) -> dict:
    if not is_api_configured():
        raise HTTPException(status_code=400, detail="请先在界面中配置 OpenAI API Key")

    raw_total = len(emails)
    others, delivery = split_delivery_emails(emails)
    delivery_summaries = build_delivery_summaries(delivery)

    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    email_text = ""
    for i, em in enumerate(others, 1):
        email_text += f"\n【邮件{i}】来自邮箱:{em['account']} | 发件人:{em['from']} | 时间:{em['time']}\n"
        email_text += f"主题：{em['subject']}\n"
        if em.get("body"):
            email_text += f"正文摘录：{em['body'][:200]}\n"

    delivery_note = ""
    if delivery:
        delivery_note = f"\n另有 {len(delivery)} 封常规配送/物流通知邮件已由系统自动汇总，请勿在 emails 数组中逐封列出。\n"

    if not others:
        result = {
            "date": date.today().isoformat(),
            "insight": f"今日共 {raw_total} 封邮件，均为配送通知，无异常需处理。",
            "emails": delivery_summaries,
        }
        return enrich_report(result, raw_total=raw_total)

    default_system = """你是亚马逊跨境电商运营邮件分析助手。对每封邮件必须归类到且仅归类到一个主分类，并给出1-2个具体子标签。

【五大主分类 — category 字段只能填以下之一】

1. 风险邮件（最高优先级，需立即处理）
   适用：差评、1-3星Review、A-to-Z索赔、Chargeback拒付、买家威胁差评、恶意投诉、侵权下架通知、假冒商品警告、账号被限制销售/暂停/listing被移除
   子标签示例：差评预警、A-to-Z索赔、Chargeback、侵权下架、Listing移除、恶意投诉

2. 账号警告（高优先级，24小时内处理）
   适用：账号健康度通知、ODR/迟发率/取消率超标、客服响应超时、政策合规警告、账号审核/KYC、身份验证、Brand Registry问题、跟卖投诉处理结果
   子标签示例：账号健康、ODR超标、迟发率警告、政策违规、账号审核、身份验证

3. 待处理（中优先级，需回复或操作）
   适用：买家站内信、退货/退款请求、换货、FBA货件差异/丢失/损坏、Inbound问题、Case需回复、发票/税号请求、亚马逊调查问卷需回复
   子标签示例：买家消息、退货退款、FBA货件、Case待回复、发票请求

4. 重要邮件（中低优先级，需知晓但不必立刻回复）
   适用：FBA库存低/断货预警、补货提醒、物流签收/到仓、付款成功/失败、月结账单、仓储费、长期仓储费、VAT/GST税务、供应商/货代通知、银行到账
   子标签示例：库存预警、物流到仓、付款账单、仓储费用、税务通知、供应链

5. 广告通知（低优先级，可批量处理或忽略）
   适用：SP/SB/SD广告报告、广告账单、Budget耗尽、Coupon/Lightning Deal邀请、促销到期、Amazon Ads政策、Brand Analytics报告
   子标签示例：SP广告、SB/SD广告、广告账单、促销邀请、Coupon到期

【优先级 priority 映射】
- 风险邮件、账号警告 → 高
- 待处理、重要邮件 → 中
- 广告通知 → 低

【tags 规则】
- 从上述子标签中选1-2个最匹配的，用简短中文（4-8字）
- 不要发明新主分类名称

【配送邮件汇总规则】
- 常规发货/配送/签收/在途更新类邮件不要逐封输出
- 这类邮件由系统自动汇总，你只需分析非配送类邮件"""

    final_system = system_prompt.strip() if system_prompt and system_prompt.strip() else default_system

    user_prompt = f"""分析重点：{focus}
{delivery_note}
以下是需要逐封分析的非配送类邮件（共 {len(others)} 封）：
{email_text if others else "（无，仅配送汇总）"}

请严格按以下JSON格式返回（不含任何其他文字）：
{{
  "date": "{date.today().isoformat()}",
  "total": 邮件总数,
  "urgent": 风险邮件+账号警告的数量,
  "needReply": 待处理的数量,
  "handled": 广告通知的数量,
  "insight": "50字以内整体运营洞察，说明今日最需要关注什么",
  "emails": [
    {{
      "account": "来自哪个邮箱备注名",
      "from": "发件人名称（简化）",
      "time": "HH:MM",
      "subject": "邮件主题",
      "summary": "60字以内摘要，提炼运营关键信息",
      "category": "风险邮件|账号警告|待处理|重要邮件|广告通知 之一",
      "tags": ["具体子标签1", "具体子标签2"],
      "priority": "高/中/低"
    }}
  ]
}}"""

    try:
        response = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[
                {"role": "system", "content": final_system},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.3,
            max_tokens=2000,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"GPT 调用失败: {e}")

    raw = response.choices[0].message.content.strip()
    raw = raw.replace("```json", "").replace("```", "").strip()

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="GPT 返回格式错误，请重试")

    emails_out = parsed.get("emails") or []
    emails_out.extend(delivery_summaries)
    parsed["emails"] = emails_out
    return enrich_report(parsed, raw_total=raw_total)


@app.post("/analyze")
def analyze_emails(req: AnalyzeRequest):
    try:
        all_emails = []

        for account in req.accounts:
            emails = fetch_today_emails(account, req.max_emails)
            all_emails.extend(emails)

        if not all_emails:
            return enrich_report({
                "date": date.today().isoformat(),
                "insight": "今日暂无邮件",
                "emails": [],
            }, raw_total=0)

        return analyze_with_gpt(all_emails, req.focus, req.system_prompt)
    except HTTPException:
        raise
    except Exception as e:
        print(f"analyze error: {e}")
        raise HTTPException(status_code=500, detail=f"分析失败: {e}")


@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.now().isoformat()}


if __name__ == "__main__":
    port = int(os.getenv("MAILWATCH_PORT", "8000"))

    def open_browser():
        time.sleep(1.2)
        webbrowser.open(f"http://127.0.0.1:{port}")

    if os.getenv("MAILWATCH_NO_BROWSER") != "1":
        threading.Thread(target=open_browser, daemon=True).start()

    print("\n MailWatch running")
    print(f"   http://127.0.0.1:{port}")
    print("   Close this window to stop\n")
    uvicorn.run(app, host="127.0.0.1", port=port, reload=False)
